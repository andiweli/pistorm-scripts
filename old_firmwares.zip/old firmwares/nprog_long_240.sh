sudo openocd -f ./nprog/68_long_240.cfg
