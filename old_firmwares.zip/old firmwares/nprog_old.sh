sudo openocd -f ./nprog/68old.cfg
