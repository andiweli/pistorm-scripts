sudo openocd -f ./nprog/68_long.cfg
